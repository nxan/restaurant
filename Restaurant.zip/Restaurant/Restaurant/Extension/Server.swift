//
//  Server.swift
//  Restaurant
//
//  Created by NXA on 6/8/19.
//  Copyright © 2019 NXA. All rights reserved.
//

import Foundation

class Server {
    let url = "https://restaurant-api-e1804.herokuapp.com/"
}
