//
//  MenuHelper.swift
//  Restaurant
//
//  Created by NXA on 5/5/19.
//  Copyright © 2019 NXA. All rights reserved.
//

import Foundation

class MenuHelper {
    
    
}
