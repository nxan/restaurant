//
//  CartTableSectionHeader.swift
//  Restaurant
//
//  Created by NXA on 5/6/19.
//  Copyright © 2019 NXA. All rights reserved.
//

import UIKit

class CartTableSectionHeader: UITableViewCell {
    
    @IBOutlet weak var labelHeader: UILabel!    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
